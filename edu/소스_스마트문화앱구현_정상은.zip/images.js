import Delete from '../assets/icon/delete.png';
import Checked from '../assets/icon/checked.png';
import Unchecked from '../assets/icon/unchecked.png';
import Update from '../assets/icon/update.png';

export const images = {
  delete: Delete,
  checked : Checked,
  unchecked:Unchecked,
  update:Update,
}